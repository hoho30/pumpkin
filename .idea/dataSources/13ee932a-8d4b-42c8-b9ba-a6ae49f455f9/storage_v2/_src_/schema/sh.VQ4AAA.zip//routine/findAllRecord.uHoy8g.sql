create
    definer = root@localhost procedure findAllRecord()
begin
    select *
        from record;
end;

