create
    definer = root@localhost procedure addSales(IN gid int, IN num int)
begin
    declare x int;
    select sales into x
    from goods
        where goods.id=gid;
        set x = x+num;
        update goods
            set sales=x
    where id=gid;

end;

