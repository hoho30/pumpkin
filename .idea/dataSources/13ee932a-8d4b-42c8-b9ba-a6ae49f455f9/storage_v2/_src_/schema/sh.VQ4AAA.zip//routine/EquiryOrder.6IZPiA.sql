create
    definer = root@localhost procedure EquiryOrder(IN uname varchar(255))
begin
    select id,date,goodsid,number,name,price
        from `order`,order_goods
            where `order`.username=uname and `order`.id=order_goods.orderid;

end;

