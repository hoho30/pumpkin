create
    definer = root@localhost procedure equiryOrderid(IN uname varchar(255), IN dtime datetime)
begin
    select id
        from `order`
            where uname=username and dtime=date;
end;

