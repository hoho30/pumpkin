create
    definer = root@localhost procedure InsertOrders(IN uname varchar(255), IN dtime datetime)
begin
    declare i int;
    insert into `order`(date,username)
    values (dtime,uname);
end;

