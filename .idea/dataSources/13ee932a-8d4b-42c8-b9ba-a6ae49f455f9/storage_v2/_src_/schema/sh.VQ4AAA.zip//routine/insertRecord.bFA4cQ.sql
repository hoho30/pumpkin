create
    definer = root@localhost procedure insertRecord(IN dtime datetime, IN uname varchar(255), IN s varchar(255),
                                                    IN i varchar(255))
begin 
    insert into record
    values (dtime,uname,s,i);
end;

