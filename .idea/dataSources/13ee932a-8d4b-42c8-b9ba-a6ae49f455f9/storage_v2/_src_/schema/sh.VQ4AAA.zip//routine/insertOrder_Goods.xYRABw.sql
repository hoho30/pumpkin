create
    definer = root@localhost procedure insertOrder_Goods(IN oid int, IN gid int, IN num int, IN gname varchar(255), IN gprice int)
begin
    insert into order_goods
    values (oid,gid,num,gname,gprice);
end;

